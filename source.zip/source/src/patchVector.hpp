/**
* @file Ptexton.hpp
* @brief The class for the vetor of each patches in an images
* @author Eunbi Park
* @date 2015.11.24
*/

#ifndef PATCHVECTOR_HPP
#define PATCHVECTOR_HPP

#endif PATCHVECTOR_HPP